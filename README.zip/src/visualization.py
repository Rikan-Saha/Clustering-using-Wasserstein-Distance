import plotly.graph_objects as go


def plot_clusters_interactive(data, clusters):
    """
    Interactive cluster-wise histogram plots using Plotly
    """

    unique_clusters = set(clusters)

    for cluster_id in unique_clusters:
        fig = go.Figure()

        for i, dist in enumerate(data):
            if clusters[i] == cluster_id:
                fig.add_trace(
                    go.Histogram(
                        x=dist,
                        nbinsx=20,
                        opacity=0.5,
                        name=f"Sample {i}",
                    )
                )

        fig.update_layout(
            title=f"Cluster {cluster_id}",
            xaxis_title="Value",
            yaxis_title="Frequency",
            barmode="overlay",
            template="plotly_white"
        )

        fig.show()